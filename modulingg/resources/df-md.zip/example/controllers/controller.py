def test_controller():
    print("Testing controller")